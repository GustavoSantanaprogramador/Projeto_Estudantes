/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade_repeticao_23_02;

import java.util.Scanner;

public class Atividade_repeticao_23_02 {

    public static void main(String[] args) {
     Scanner ler = new Scanner(System.in);
         
     System.out.println("Infome um numero: ");
          int x = ler.nextInt();
          
     while(x <= 10)
     {
         x = 3* x;
          
         System.out.println(x);
     }
   
    }
}
