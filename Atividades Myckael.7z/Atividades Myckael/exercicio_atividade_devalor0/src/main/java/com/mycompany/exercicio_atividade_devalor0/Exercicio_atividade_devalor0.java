/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercicio_atividade_devalor0;

/**
 *
 * @author lnunes
 */
import java.util.Scanner;
public class Exercicio_atividade_devalor0 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        
        System.out.println("Digite um valor: ");
         int valorUm = ler.nextInt();
         
        System.out.println("Digite outro valor: ");
         int valorDois = ler.nextInt();
         
         
      if(valorDois == 0){
        System.out.println("DIGITE UM NUMERO DIFERENTE DE 0");
      }else{
        System.out.println("A divisão entre o primeiro e o segundo valor é: " + valorUm / valorDois);
      }
    }
}
