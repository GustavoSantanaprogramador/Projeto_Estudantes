/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade_compara_string;

import java.util.Scanner;

/**
 *
 * @author lnunes
 */
public class Atividade_compara_string {

    public static void main(String[] args) {
        Scanner ler = new Scanner (System.in);
        String  cidade = ler.nextLine();
        
        if(cidade.equalsIgnoreCase("Vitoria")){
          System.out.println("Custo frete R$100");
        }else if(cidade.equalsIgnoreCase("Vila Velha")){
          System.out.println("Custo frete R$50");
        }else if(cidade.equalsIgnoreCase("Serra")){
          System.out.println("Custo frete R$40");
    }
}
}