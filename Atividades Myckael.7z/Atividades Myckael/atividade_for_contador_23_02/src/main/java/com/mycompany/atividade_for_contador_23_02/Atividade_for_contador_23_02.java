/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade_for_contador_23_02;

/**
 *
 * @author lnunes
 */
public class Atividade_for_contador_23_02 {

    public static void main(String[] args) {
        
        for(int i=1; i<= 10;i++){
            
        System.out.println(i);

        }
       }
    }

