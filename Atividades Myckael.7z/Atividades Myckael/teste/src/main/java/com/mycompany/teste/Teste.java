/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.teste;

/**
 *
 * @author lnunes
 */
public class Teste {

    public static void main(String[] args) {
        String valor = "1.5";
        
        try{
            int valorI = Integer.parseInt(valor);
             System.out.println("Valor inteiro: " + valorI);
        }catch(NumberFormatException e){
             System.out.println("Erro ao converter " + e.getMessage());      
        }
       
    }
}
