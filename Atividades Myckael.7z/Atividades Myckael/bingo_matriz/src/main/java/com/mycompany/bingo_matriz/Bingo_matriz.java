/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bingo_matriz;

/**
 *
 * @author lnunes
 */
import java.util.Scanner;
public class Bingo_matriz {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in); 
        
        
     
        
        int mUser[][]= new int[l][c];
        
        int m[][] = {{11,22,33},
                     {44,55,66},
                     {77,88,99}};
      
        
        
        System.out.println("Qual linha você deseja ver? ");
           int l = ler.nextInt();
           
        System.out.println("Qual coluna você deseja ver? ");
           int c = ler.nextInt();
        
           
        int resultado = 
         System.out.println("A posição da linha que voce digitou é:  " + linha + coluna + m[linha][coluna]);   
       
    }
}
