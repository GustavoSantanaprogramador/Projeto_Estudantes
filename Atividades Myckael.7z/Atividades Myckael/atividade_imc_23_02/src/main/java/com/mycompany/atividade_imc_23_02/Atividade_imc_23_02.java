
package com.mycompany.atividade_imc_23_02;


import java.util.Scanner;

public class Atividade_imc_23_02 {

    public static void main(String[] args) {
     Scanner ler = new Scanner(System.in);
      
              
      System.out.println("Infome sua Altura: ");
          float altura = ler.nextFloat();
          
        System.out.println("Infome seu peso:");
          float peso = ler.nextFloat();
          
        float imc = peso / altura;
        
        System.out.println( imc );
    }
}
