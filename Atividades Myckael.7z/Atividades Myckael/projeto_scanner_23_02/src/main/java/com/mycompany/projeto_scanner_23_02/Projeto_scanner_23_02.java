 

package com.mycompany.projeto_scanner_23_02;


import java.util.Scanner;

public class Projeto_scanner_23_02 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
                
        System.out.println("Infome seu nome completo: ");
          String nomeCompleto = ler.nextLine();
          
        System.out.println("Infome sua idade:");
          int idade = ler.nextInt();
         
        System.out.println("Infome sua data de nascimento: ");
          String dataNasc = ler.next();
         
        System.out.println("Infome seu ultimo salario: ");
          int ultimoSalario = ler.nextInt();
        
        System.out. println(nomeCompleto);
        System.out. println(idade);
        System.out. println(dataNasc);
        System.out. println(ultimoSalario);
                  
    }
}
