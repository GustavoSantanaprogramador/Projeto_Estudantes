/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividadefloatdez;

/**
 *
 * @author lnunes
 */
import java.util.Scanner;
public class AtividadeFloatDez {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);  
     
        int x = 10;
        float v[] = new float[x];
        int i;
        float soma = 0;
        
        for (i = 0; i < x; i++){
        System.out.println("Digite um valor:"); 
        v[i] = ler.nextFloat();  
        }
        for(i = 0; i < x; i++){
          soma = (soma + v[i]);
        }
        System.out.print( "Resultado: " + soma);
    }
}
