/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_capixaba_cap;

/**
 *
 * @author lnunes
 */
import java.util.Scanner;
import java.util.Random;
public class Projeto_capixaba_cap {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        
        
        int[][] matriz = new int[20][20];
        
        Random random = new Random();
         for (int i = 0; i < 20; i++) {
            for (int j = 0; j < 20; j++) {
                matriz[i][j] = random.nextInt(401); // Gera números de 0 a 400
            }
        }
             
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite 10 números separados por virgula: ");
        String input = scanner.nextLine();
        String[] numerosDigitados = input.split(",");

            for (String numero : numerosDigitados) {
            int num = Integer.parseInt(numero);
            boolean encontrado = false;

            for (int i = 0; i < 20; i++) {
                for (int j = 0; j < 20; j++) {
                    if (matriz[i][j] == num) {
                        System.out.println("Número " + num + " encontrado na posição (" + i + ", " + j + ")");
                        encontrado = true;
                      
                    }
                }
                if (encontrado) {
                                 }
            }

            if (!encontrado) {
                System.out.println("Número " + num + " não encontrado na matriz.");
            }
        }
    }
}


