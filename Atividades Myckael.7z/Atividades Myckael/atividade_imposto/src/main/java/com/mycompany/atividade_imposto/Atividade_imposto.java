/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade_imposto;

import java.util.Scanner;

/**
 *
 * @author lnunes
 */
public class Atividade_imposto {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        String MG;
        String MS;      
        String SP; 
        String RJ;    
        
         System.out.println("Infome o valor do produto: ");
          int valor = ler.nextInt();
          
          System.out.println("Infome um estado abaixo: ");
          String estado = ler.next();

        if(estado.equalsIgnoreCase("MG")){
            
           System.out.println(valor + (valor * 0.07));
           
        }else  if(estado.equalsIgnoreCase("SP")){
            
           System.out.println(valor + (valor * 0.12));
           
        }else if(estado.equalsIgnoreCase("MS")) {
            
           System.out.println(valor + (valor * 0.08));  
           
        } else if(estado.equalsIgnoreCase("RJ")) {
            
           System.out.println(valor + (valor * 0.15));      
        }else{
         System.out.println("ESTADO INVALIDO!");  
         
        }
            System.out.println(valor);
      }                                                 
}   
    