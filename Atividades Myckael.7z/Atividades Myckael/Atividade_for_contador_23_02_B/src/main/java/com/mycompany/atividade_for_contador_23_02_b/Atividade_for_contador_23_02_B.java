/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade_for_contador_23_02_b;

/**
 *
 * @author lnunes
 */
public class Atividade_for_contador_23_02_B {

    public static void main(String[] args) {
          
        for(int i=10; i>= 1;i--){
            
        System.out.println(i);

        }
    }
}
