/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade_26_02;

import java.util.Scanner;

/**
 *
 * @author lnunes
 */

public class Atividade_26_02 {

    public static void main(String args[]) {
        Scanner ler = new Scanner (System.in);
        System.out.println("Insira uma palavra (string): ");
        String msg = ler.nextLine();
         
        int ctA = 0, ctE = 0, ctI = 0, ctO = 0, ctU = 0;
       
        
        for (int i=0; i<msg.length(); i++){
            switch (msg.charAt(i)){
                case 'a':
                case 'A': ctA += 1;
                          break;
                case 'e':
                case 'E': ctE += 1;
                          break;          
                case 'i':
                case 'I': ctI += 1;
                          break;   
                case 'o':
                case 'O': ctO += 1;
                          break;
                case 'u':
                case 'U': ctU += 1;
                          break;
            }
        }
        System.out.println("A quantidade de caracteres com a letra A foi: " + ctA);
        System.out.println("A quantidade de caracteres com a letra E foi: " + ctE);
        System.out.println("A quantidade de caracteres com a letra I foi: " + ctI);
        System.out.println("A quantidade de caracteres com a letra O foi: " + ctO);
        System.out.println("A quantidade de caracteres com a letra U foi: " + ctU);

    }
}
