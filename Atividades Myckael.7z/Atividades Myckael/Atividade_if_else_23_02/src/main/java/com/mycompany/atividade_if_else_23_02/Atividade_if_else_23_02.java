/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade_if_else_23_02;

/**
 *
 * @author lnunes
 */
import java.util.Scanner;

public class Atividade_if_else_23_02 {

    public static void main(String[] args) {
      Scanner ler = new Scanner(System.in);
     
        
        System.out.println("Infome um numero: ");
          int x = ler.nextInt();
          
        if (x >= 10){
         System.out.println(12);
        }else if(x<=7){
         System.out.println(11);
        }
        else if(x>8){
         System.out.println(10);
        }
    }
}
