/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fixacao_classes_lahra;

/**
 *
 * @author lnunes
 */
import java.util.Scanner;

public class Fixacao_classes_lahra {

    public static void main(String[] args) {
       Scanner ler = new Scanner(System.in);
       
       while (true){ 
        System.out.println("Informe o numero, (-1) para encerrar:  ");
        int n = ler.nextInt();
        if (n == -1)
            break;
        
        tabuada(n);
        
        System.out.println("Fatorial de " + n + " " + fatorial(n));
    }
       
   }
     public static void tabuada(int n){
     for(int i=1; i <= 10; i++){
          System.out.println(i*n);         
         }
     }
     
     public static long fatorial(int n){
         long f = 1;
         for(int i=1; i< n; i++){
             f = f * i;       
         }
         
         return(f);
     }
}
