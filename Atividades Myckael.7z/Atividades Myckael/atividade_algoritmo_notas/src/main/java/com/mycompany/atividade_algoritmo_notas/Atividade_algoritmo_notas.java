/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade_algoritmo_notas;

/**
 *
 * @author lnunes
 */
import java.util.Scanner;
public class Atividade_algoritmo_notas {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        
         System.out.println("Digite uma nota: ");
         int notaUm = ler.nextInt();
         
        System.out.println("Digite outra nota: ");
         int notaDois = ler.nextInt();
         
         if (notaUm >= 0 && notaUm <= 10 && notaDois >= 0 && notaDois <=10){
              System.out.println("O resultado da sua media é: " + (notaUm + notaDois) / 2);      
        
         }else{
               System.out.println(" Notas devem ser numeros entre 0 a 10! ");           
          }
         
         
         
         
         
          System.out.println("Deseja fazer novo calculo? S/N ");
           String resposta = ler.next();
  
         if(resposta.equalsIgnoreCase("S")){
             System.out.println("Digite uma nota: ");
         int notaTres = ler.nextInt();
         
        System.out.println("Digite outra nota: ");
         int notaQuatro = ler.nextInt();
         
         if (notaQuatro >= 0 && notaQuatro <= 10 && notaTres >= 0 && notaTres <=10){
              System.out.println("O resultado da sua media é: " + (notaQuatro + notaTres) / 2);      
        
         }else{
               System.out.println(" Notas devem ser numeros entre 0 a 10! ");           
          }
   
         }
    }
}
